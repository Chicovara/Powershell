# Dokumentation zur Erstellung eins bootfähigen USB-Mediums mit GRUB loop und Windows chainload

### 0. Voraussetzungen

- Ubuntu
- 32GB USB-Stick
- SecureBoot deaktiviert
- CSM-Support UEFI-Only oder Disable

## 1. Vorbereitungen

### 1.1 Ubuntu Einrichten

sudo apt update  
sudo apt install grub-efi-amd64-bin grub2-common

## 1.2 USB-Stick partitioniern

4GB FAT/FAT32 LABEL=USB-EFI
[Rest] GB NTFS LABEL=USB-DATA

## 2 GRUB installieren

sudo mkdir  /mnt/usb-efi /mnt/usb-data
sudo mount /dev/sdX1 /mnt/usb-efi
sudo mount /dev/sdX2 /mnt/usb-data

sudo grub-install --target=x86_64-efi --efi-directory=/mnt/usb-efi --boot-directory=/mnt/usb-efi/boot --removable --no-nvram

sudo mkdir  /mnt/usb-efi/boot /mnt/usb-efi/boot/grub

## 3 grub.cfg anpassen

- 'hd0,2' auf tasächliches ändern. Ggf UUID nutzen
- Namen der Ubuntu iso ggf. Anpassen

## 4 CFG-Datei und mod-Dateien ablegen

sudo cp /[PATH]/grub.cfg /mnt/usb-efi/boot/grub/grub.cfg
sudo cp /[PATH]/x86_64-efi /mnt/usb-efi/boot/grub/x86_64-efi/

## 5 ISOs und Win-Daten ablegen

sudo mkdir /mnt/usb-data/iso
sudo cp /[PATH]/ubuntu-XYZ.iso /mnt/usb-data/ISO/ubuntu-XYZ.iso

## 6 Starten


